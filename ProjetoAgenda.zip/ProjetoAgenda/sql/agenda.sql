create table contato(
id int (100)PRIMARY KEY AUTO_INCREMENT not NULL ,
nome VARCHAR(100) NOT NULL,
telefone VARCHAR(100) null,
email VARCHAR(100) NULL
);